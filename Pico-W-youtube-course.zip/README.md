# Raspberry Pi Pico W course by Paul McWhorter - My exercise files

course:
https://www.youtube.com/playlist?list=PLGs0VKk2DiYz8js1SJog21cDhkBqyAhC5


Raspberry Pi pico python SDK:
https://datasheets.raspberrypi.com/pico/raspberry-pi-pico-python-sdk.pdf

