"""
Module: 'os' on micropython-rp2-1.15
"""
# MCU: {'family': 'micropython', 'sysname': 'rp2', 'version': '1.15.0', 'build': '', 'mpy': 5637, 'port': 'rp2', 'platform': 'rp2', 'name': 'micropython', 'arch': 'armv7m', 'machine': 'Raspberry Pi Pico with RP2040', 'nodename': 'rp2', 'ver': '1.15', 'release': '1.15.0'}
# Stubber: 1.3.9

class VfsFat:
    ''
    def chdir():
        pass

    def getcwd():
        pass

    def ilistdir():
        pass

    def mkdir():
        pass

    def mkfs():
        pass

    def mount():
        pass

    def open():
        pass

    def remove():
        pass

    def rename():
        pass

    def rmdir():
        pass

    def stat():
        pass

    def statvfs():
        pass

    def umount():
        pass


class VfsLfs2:
    ''
    def chdir():
        pass

    def getcwd():
        pass

    def ilistdir():
        pass

    def mkdir():
        pass

    def mkfs():
        pass

    def mount():
        pass

    def open():
        pass

    def remove():
        pass

    def rename():
        pass

    def rmdir():
        pass

    def stat():
        pass

    def statvfs():
        pass

    def umount():
        pass

def chdir():
    pass

def getcwd():
    pass

def ilistdir():
    pass

def listdir():
    pass

def mkdir():
    pass

def mount():
    pass

def remove():
    pass

def rename():
    pass

def rmdir():
    pass

def stat():
    pass

def statvfs():
    pass

def umount():
    pass

def uname():
    pass

def urandom():
    pass

